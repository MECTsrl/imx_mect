#include <stdio.h>

int main(void)
{
	printf("hallo\n");
	return 0;
}
